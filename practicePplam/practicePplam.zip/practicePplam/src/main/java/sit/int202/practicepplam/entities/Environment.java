package sit.int202.practicepplam.entities;

public class Environment {
    public static final String UNIT_NAME = "classic-models";
}
